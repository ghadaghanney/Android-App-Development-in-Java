package com.example.imc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText tailleTxt, poidTxt ;
    private Button btn ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tailleTxt = (EditText) findViewById(R.id.taille_txt);
        poidTxt = (EditText) findViewById(R.id.poid_txt);
        btn = (Button) findViewById(R.id.calc_btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float tailleVal = Float.parseFloat(tailleTxt.getText().toString());
                float poidsVal = Float.parseFloat(poidTxt.getText().toString());

                float imc = poidsVal/(tailleVal*tailleVal);

                Toast.makeText(getApplicationContext(), ""+imc, Toast.LENGTH_SHORT).show();
            }
        });
    }
}




